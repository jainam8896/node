const mongoose = require("mongoose");

mongoose
  .connect("mongodb://localhost:27017/Blog")
  .then(() => {
    console.log("Connection successfull");
  })
  .catch((err) => {
    console.log("Not connected");
  });
