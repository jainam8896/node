/*
Git---------------------------------------------------
1. It keeps the versions of your code
2. write git init on your terminal
3. git status shows all the untracked file in your project or all the unsave file
4. git add filename this command will save the file
5. git add . this command will save all the files and folders in your project directory
6. .gitignore file - those files which we want to ignore are put in the .gitignore
7. then add .gitignore
8. git rm -r --cached node_modules
9. to save the snapshot type git commit -m "first version of my project"
10. after creating repository on github, whatever command is written over there paste it on your terminal
11. git push command to push the updated file
12. to pull the changes from your github to visual studio write git pull on terminal
13. mongodb atlas is used to host database online
14. host nodejs server online
15. host website on render
*/