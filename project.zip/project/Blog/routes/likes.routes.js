const postLike = require("../controllers/likes/postLike.js");
const postUnlike = require("../controllers/likes/postUnlike.js");
const postLikeCount = require("../controllers/likes/postLikeCount.js");
const checkUserAuth = require("../middlewares/auth.js");
const express = require("express");
const router = express.Router();
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");

router.post(
  "/:postid/likes/post-like",
  checkUserAuth,
  asyncErrorHandler(async function _postLike(req, res, next) {
    const data = await postLike(req.params, req.authUser);
    return res.status(201).json({ message: "Post liked", data: data });
  })
);

router.post(
  "/:postid/likes/post-unlike",
  checkUserAuth,
  asyncErrorHandler(async function _postUnlike(req, res, next) {
    const data = await postUnlike(req.params, req.authUser);
    return res.status(200).json({ message: data});
  })
);

router.get(
  "/:postid/likes/like-count",
  checkUserAuth,
  asyncErrorHandler(async function _postLikeCount(req, res, next) {
    const data = await postLikeCount(req.params);
    return res.status(200).json({ message: "Post like counts", data: data});
  })
);

module.exports = router;
