const updateUser = require("../controllers/users/updateUser");
const deleteUser = require("../controllers/users/deleteUser");
const getUser = require("../controllers/users/getUser");
const searchUser = require("../controllers/users/searchUser");
const router = require("express").Router();
const rules = require("../utils/validations/rules.js");
const validate = require("../middlewares/validate.js");
const checkUserAuth = require("../middlewares/auth.js");
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");
const upload = require("../helpers/profileUpload.js");

router.patch(
  "/:id",
  checkUserAuth,
  upload.single("postimage"),
  validate(rules.updateUserValidation),
  asyncErrorHandler(async function _updateUser(req, res, next) {
    const data = await updateUser(req.body, req.params, req.file);
    return res
      .status(200)
      .json({ message: "Your information updated successfully", data: data });
  })
);

router.get(
  "/:id",
  checkUserAuth,
  asyncErrorHandler(async function _getUser(req, res, next) {
    const data = await getUser(req.params);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

router.delete(
  "/:id",
  checkUserAuth,
  asyncErrorHandler(async function _deleteUser(req, res, next) {
    const data = await deleteUser(req.params);
    return res.status(200).json({ message: data });
  })
);

router.get(
  "/",
  checkUserAuth,
  asyncErrorHandler(async function _searchUser(req, res, next) {
    const data = await searchUser(req.query);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

module.exports = router;