const router = require("express").Router();
router.use("/authentication", require("./authentication.routes"));
router.use("/posts", require("./posts.routes"));
router.use("/categories", require("./categories.routes"));
router.use("/posts", require("./comments.routes"));
router.use("/posts/", require("./likes.routes"));
router.use("/users", require("./users.routes"));
module.exports = router;
