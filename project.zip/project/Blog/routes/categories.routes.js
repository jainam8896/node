const addCategory = require("../controllers/categories/addCategory");
const updateCategory = require("../controllers/categories/updateCategory");
const deleteCategory = require("../controllers/categories/deleteCategory");
const listCategory = require("../controllers/categories/listCategory");
const getCategory = require("../controllers/categories/getCategory.js");
const router = require("express").Router();
const rules = require("../utils/validations/rules.js");
const validate = require("../middlewares/validate.js");
const checkUserAuth = require("../middlewares/auth.js");
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");

router.post(
  "/",
  checkUserAuth,
  validate(rules.categoryValidation),
  asyncErrorHandler(async function _addCategory(req, res, next) {
    const data = await addCategory(req.body);
    return res
      .status(201)
      .json({ message: "Blog posted successfully", data: data });
  })
);

router.put(
  "/:id",
  checkUserAuth,
  validate(rules.categoryValidation),
  asyncErrorHandler(async function _updateCategory(req, res, next) {
    const data = await updateCategory(req.body, req.params);
    return res
      .status(200)
      .json({ message: "Category updated successfully", data: data });
  })
);

router.delete(
  "/:id",
  checkUserAuth,
  asyncErrorHandler(async function _deleteCategory(req, res, next) {
    const data = await deleteCategory(req.params);
    return res.status(200).json({ message: data });
  })
);

router.get(
  "/",
  asyncErrorHandler(async function _listCategory(req, res, next) {
    const data = await listCategory(req.query);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

router.get(
  "/:id",
  asyncErrorHandler(async function _getCategory(req, res, next) {
    const data = await getCategory(req.params);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

module.exports = router;
