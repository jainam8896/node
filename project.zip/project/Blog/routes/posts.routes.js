const addPost = require("../controllers/posts/addPost");
const updatePost = require("../controllers/posts/updatePost");
const deletePost = require("../controllers/posts/deletePost");
const listPost = require("../controllers/posts/listPost");
const getPost = require("../controllers/posts/getPost");
const router = require("express").Router();
const rules = require("../utils/validations/rules.js");
const validate = require("../middlewares/validate.js");
const checkUserAuth = require("../middlewares/auth.js");
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");
const upload = require("../helpers/postUpload.js");

router.post(
  "/",
  checkUserAuth,
  upload.single("postimage"),
  validate(rules.postValidation),
  asyncErrorHandler(async function _addPost(req, res, next) {
    const data = await addPost(req.body, req.authUser, req.file);
    return res
      .status(201)
      .json({ message: "Blog posted successfully", data: data });
  })
);

router.put(
  "/:id",
  checkUserAuth,
  upload.single("postimage"),
  validate(rules.postValidation),
  asyncErrorHandler(async function _updatePost(req, res, next) {
    const data = await updatePost(req.body, req.authUser, req.params, req.file);
    return res
      .status(200)
      .json({ message: "Blog updated successfully", data: data });
  })
);

router.delete(
  "/:id",
  checkUserAuth,
  asyncErrorHandler(async function _deletePost(req, res, next) {
    const data = await deletePost(req.params);
    return res.status(200).json({ message: data });
  })
);

router.get(
  "/",
  asyncErrorHandler(async function _listPost(req, res, next) {
    const data = await listPost(req.query);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

router.get(
  "/:id",
  asyncErrorHandler(async function _getPost(req, res, next) {
    const data = await getPost(req.params);
    return res
      .status(200)
      .json({ message: "Request executed successfully", data: data });
  })
);

module.exports = router;
