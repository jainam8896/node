const addComment = require("../controllers/comments/addComment");
const updateComment = require("../controllers/comments/updateComment");
const deleteComment = require("../controllers/comments/deleteComment");
const listComment = require("../controllers/comments/listComment");
const router = require("express").Router();
const rules = require("../utils/validations/rules.js");
const validate = require("../middlewares/validate.js");
const checkUserAuth = require("../middlewares/auth.js");
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");

router.post(
  "/:postid/comments",
  checkUserAuth,
  validate(rules.commentValidation),
  asyncErrorHandler(async function _addComment(req, res, next) {
    const data = await addComment(req.body, req.authUser, req.params);
    return res
      .status(201)
      .json({ message: "Comment posted successfully", data: data });
  })
);

router.put(
  "/:postid/comments/:id",
  checkUserAuth,
  validate(rules.commentValidation),
  asyncErrorHandler(async function _updateComment(req, res, next) {
    const data = await updateComment(req.body, req.authUser, req.params);
    return res
      .status(200)
      .json({ message: "Comment updated successfully", data: data });
  })
);

router.delete(
  "/:postid/comments/:id",
  checkUserAuth,
  asyncErrorHandler(async function _deleteComment(req, res, next) {
    const data = await deleteComment(req.params);
    return res.status(200).json({ message: data });
  })
);

router.get(
  "/:postid/comments/",
  asyncErrorHandler(async function _listComment(req, res, next) {
    const data = await listComment();
    return res.status(200).json({ message: "All Comments", data: data });
  })
);

module.exports = router;
