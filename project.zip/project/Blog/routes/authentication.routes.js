const signup = require("../controllers/authentication/signup");
const verifyMail = require("../controllers/authentication/verifyMail.js");
const login = require("../controllers/authentication/login");
const changePassword = require("../controllers/authentication/changePassword");
const forgotPassword = require("../controllers/authentication/forgotPassword");
const resetPassword = require("../controllers/authentication/resetPassword");
const checkUserAuth = require("../middlewares/auth.js");
const rules = require("../utils/validations/rules.js");
const validate = require("../middlewares/validate.js");
const express = require("express");
const router = express.Router();
const asyncErrorHandler = require("../utils/errors/asyncErrorHandler.js");
const upload = require("../helpers/profileUpload");

router.use(express.static("public"));

router.post(
  "/signup",
  upload.single("profileimage"),
  validate(rules.signupValidation),
  asyncErrorHandler(async function _signup(req, res, next) {
    const data = await signup(req.body, req.file);
    return (
      res
        .status(201)
        // .json({ data: data, message: "Request executed successfully" });
        .json({ message: data })
    );
  })
);

router.get(
  "/verify",
  asyncErrorHandler(async function _verifyMail(req, res, next) {
    const data = await verifyMail(req.query);
    return res
      .status(200)
      .json({ message: "Email verified successfully", data: data });
  })
);

router.post(
  "/login",
  validate(rules.loginValidation),
  asyncErrorHandler(async function _login(req, res, next) {
    const data = await login(req.body);
    return res.status(200).json({ token: data, message: "Login successfull" });
  })
);

router.put(
  "/changepassword",
  checkUserAuth,
  validate(rules.changePasswordValidation),
  asyncErrorHandler(async function _changePassword(req, res, next) {
    const data = await changePassword(req.body, req.authUser);
    return res.status(200).json({ message: data });
  })
);

router.post(
  "/forgotpassword",
  validate(rules.forgotPasswordValidation),
  asyncErrorHandler(async function _forgotPassword(req, res, next) {
    const data = await forgotPassword(req.body);
    return res.status(200).json({ message: data });
  })
);

router.get(
  "/resetpassword",
  validate(rules.resetPasswordValidation),
  asyncErrorHandler(async function _resetPassword(req, res, next) {
    const data = await resetPassword(req.query, req.body);
    return res.status(200).json({ message: data });
  })
);
module.exports = router;
