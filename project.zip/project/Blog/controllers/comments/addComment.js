const Comment = require("../../models/Comment");

async function addComment(params, authUser, postId) {
  const { postid } = postId;
  const { comment } = params;
  const newCommentObj = new Comment({
    comment: comment,
    user: authUser._id,
    post: postid,
  });
  const responseObj = await newCommentObj.save();
  return responseObj;
}

module.exports = addComment;
