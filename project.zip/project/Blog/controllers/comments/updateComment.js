const Comment = require("../../models/Comment");
const CustomError = require("../../utils/errors/CustomError");

async function updateComment(params, authUser, commentId) {
  const { id } = commentId;
  const { comment } = params;
  const updateCommentObj = await Comment.findByIdAndUpdate(id, {
    $set: {
      comment: comment,
      user: authUser._id,
      post: commentId.postid,
    },
  });
  if (!updateCommentObj) throw new CustomError("Comment not found", 404);
  const responseObj = await updateCommentObj.save();
  return responseObj;
}

module.exports = updateComment;
