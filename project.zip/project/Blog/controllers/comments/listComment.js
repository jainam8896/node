const Comment = require("../../models/Comment");
const CustomError = require("../../utils/errors/CustomError");

async function listComment() {
  const comments = await Comment.find({});
  if (!comments) throw new CustomError("No Comments found", 404);
  return comments;
}

module.exports = listComment;
