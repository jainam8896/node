const Comment = require("../../models/Comment");
const CustomError = require("../../utils/errors/CustomError");

async function deleteComment(commentId) {
  const { id } = commentId;
  const comment = await Comment.findByIdAndDelete(id);
  if (!comment) throw new CustomError("Comment not found", 404);
  return "Comment deleted successfully";
}

module.exports = deleteComment;
