const Category = require("../../models/Category");
const CustomError = require("../../utils/errors/CustomError");

async function updateCategory(params, categoryId) {
  const { id } = categoryId;
  const { category, parent } = params;
  const updateCategoryObj = await Category.findByIdAndUpdate(id, {
    $set: {
      category: category,
      parent: parent,
    },
  });
  if (!updateCategoryObj) throw new CustomError("Category not found", 404);
  const responseObj = await updateCategoryObj.save();
  return responseObj;
}

module.exports = updateCategory;
