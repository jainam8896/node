const Category = require("../../models/Category");
const CustomError = require("../../utils/errors/CustomError");

async function deleteCategory(categoryId) {
  const { id } = categoryId;
  const category = await Category.findByIdAndDelete(id);
  if (!category) throw new CustomError("Category not found", 404);
  return "Category deleted successfully";
}

module.exports = deleteCategory;
