const Category = require("../../models/Category");
const CustomError = require("../../utils/errors/CustomError");

async function listCategory(query) {
  var page = Number(query.page) || 1;
  const { search } = query;
  const limit = 30;
  const categories = await Category.find({
    $or: [
      { category: { $regex: ".*" + search + ".*", $options: "i" } },
      // { parent: { $regex: ".*" + search + ".*", $options: "i" } },
    ],
  })
    .select(["category", "parent"])
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .exec();
  if (!categories) throw new CustomError("No categories found", 404);
  return { categories, page };
}

module.exports = listCategory;
