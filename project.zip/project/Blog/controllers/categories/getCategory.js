const Category = require("../../models/Category");
const CustomError = require("../../utils/errors/CustomError");

async function getCategory(categoryId) {
  const { id } = categoryId;
  const categories = await Category.findById({ _id: id });
  if (!categories) throw new CustomError("No categories found", 404);
  return categories;
}

module.exports = getCategory;
