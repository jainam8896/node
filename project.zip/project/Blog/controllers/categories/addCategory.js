const Category = require("../../models/Category");

async function addCategory(params) {
  const { category, parent } = params;
  const newCategoryObj = new Category({
    category: category,
    parent: parent,
  });
  const responseObj = await newCategoryObj.save();
  return responseObj;
}

module.exports = addCategory;
