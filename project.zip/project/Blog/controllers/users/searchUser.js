const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

async function searchUser(query) {
  var page = Number(query.page) || 1;
  const { search } = query;
  const limit = 2;
  const users = await User.find({
    $or: [
      { name: { $regex: ".*" + search + ".*", $options: "i" } },
      { email: { $regex: ".*" + search + ".*", $options: "i" } },
    ],
  })
    .select(["name", "email", "mobile", "profileimage"])
    .limit(limit * 1)
    .skip((page - 1) * limit)
    .exec();
  if (!users) throw new CustomError("No user found", 404);
  return { users, page };
}

module.exports = searchUser;
