const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

async function updateUser(params, userId, image) {
  const { id } = userId;
  const { name, email, mobile } = params;
  const updateUserObj = await User.findByIdAndUpdate(id, {
    $set: {
      name: name,
      email: email,
      mobile: mobile,
      postimage: image.filename,
    },
  });
  if (!updateUserObj) throw new CustomError("User not found", 404);
  const responseObj = await updateUserObj.save();
  return responseObj;
}

module.exports = updateUser;
