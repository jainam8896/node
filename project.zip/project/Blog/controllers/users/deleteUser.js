const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

async function deleteUser(userId) {
  const { id } = userId;
  const user = await User.findByIdAndDelete(id);
  if (!user) throw new CustomError("User not found", 404);
  return "User deleted successfully";
}

module.exports = deleteUser;
