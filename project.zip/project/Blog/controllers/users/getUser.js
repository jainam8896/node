const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

async function getUser(userId) {
  const { id } = userId;
  const users = await User.findById({ _id: id }).select([
    "name",
    "email",
    "mobile",
    "profileimage",
  ]);
  if (!users) throw new CustomError("No user found", 404);
  return users;
}

module.exports = getUser;
