const Like = require("../../models/Like");
const CustomError = require("../../utils/errors/CustomError");

async function postUnlike(postId, authUser) {
  const { postid } = postId;
  const isLiked=await Like.findOne({
    user: authUser._id,
    post: postid
  });
  if(!isLiked) throw new CustomError("You have not liked", 400);
  await Like.deleteOne({
    user: authUser._id,
    post: postid
  })
  return "Post Unliked";
}

module.exports = postUnlike;