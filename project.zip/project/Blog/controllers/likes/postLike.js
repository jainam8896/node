const Like = require("../../models/Like");
const CustomError = require("../../utils/errors/CustomError");

async function postLike(postId, authUser) {
  const { postid } = postId;
  const isLiked=await Like.findOne({
    user: authUser._id,
    post: postid
  });
  if(isLiked) throw new CustomError("Already Liked", 400);
  const newLikeObj = new Like({
    user: authUser._id,
    post: postid,
  });
  const responseObj = await newLikeObj.save();
  return responseObj;
}

module.exports = postLike;
