const Like = require("../../models/Like");
const CustomError = require("../../utils/errors/CustomError");

async function postLikeCount(postId) {
  const { postid } = postId;
  const likeCount = Like.find({
    post: postid,
  }).countDocuments();
  return likeCount;
}

module.exports = postLikeCount;