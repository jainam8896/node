const User = require("../../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const CustomError = require("../../utils/errors/CustomError");

async function login(params) {
  const { email, password } = params;
  const isUserExists = await User.findOne({ email: email }).select([
    "password",
    "loginAttempts",
    "lockTime",
  ]);
  if (!isUserExists)
    throw new CustomError(
      "Sorry, user with given credentials is not found",
      401
    );
  const { lockTime, loginAttempts } = isUserExists;
  if (lockTime > Date.now()) {
    const leftTime = Math.ceil((lockTime.getTime() - Date.now()) / 60000);
    throw new CustomError(
      `Your account is locked please try after ${leftTime} minutes`,
      400
    );
  }
  const isMatch = bcrypt.compareSync(password, isUserExists.password);
  if (!isMatch) {
    isUserExists.loginAttempts += 1;
    await isUserExists.save();
    if (loginAttempts >= 3) {
      isUserExists.lockTime = Date.now() + 60000;
      await isUserExists.save();
      throw new CustomError(
        "Your account got locked for 1 hour due to multiple failed attempts",
        400
      );
    }
    throw new CustomError(
      "Sorry, user with given credentials is not found",
      401
    );
  } else {
    isUserExists.loginAttempts = 0;
    isUserExists.lockTime = null;
    isUserExists.save();
    const token = jwt.sign(
      { _id: isUserExists._id },
      process.env.JWT_SECRET_KEY,
      { expiresIn: process.env.JWT_EXPIRES }
    );
    return token;
  }
}
module.exports = login;
