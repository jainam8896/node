const User = require("../../models/User");
const bcrypt = require("bcryptjs");
const CustomError = require("../../utils/errors/CustomError");
const sendVerifyMail=require("../../helpers/sendVerifyMail");

async function signup(params, image) {
  const { name, email, mobile, password } = params;
  const isUserExists = await User.findOne({ email: email });
  if (isUserExists)
    throw new CustomError("User with given email Already exists", 400);
  const hashPassword = bcrypt.hashSync(password, 10);
  const newUserObj = new User({
    name: name,
    email: email,
    mobile: mobile,
    profileimage: image.filename,
    password: hashPassword,
  });
  await newUserObj.save();
  const responseObj = JSON.parse(JSON.stringify(newUserObj));
  delete responseObj.password;
  if(!responseObj) throw new CustomError("Your registration has been failed", 500);
  // sendVerifyMail(name, email, responseObj._id);
  return "Your registration completed successfully, Please verify your email";
  // return responseObj;
}

module.exports = signup;
