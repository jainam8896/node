const User = require("../../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const CustomError = require("../../utils/errors/CustomError");

async function resetPassword(query, params) {
  let token = query.token;
  console.log(decode(token).expire);
  const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
  const { newPassword } = params;
  const userData = await User.findById({ _id });
  if (userData.token === null)
    throw new CustomError("This link has been expired", 400);
  const hashPassword = bcrypt.hashSync(newPassword, 10);
  userData.password = hashPassword;
  userData.token = null;
  await userData.save();
  return "Your password updated successfully";
}
module.exports = resetPassword;
