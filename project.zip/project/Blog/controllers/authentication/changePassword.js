const User = require("../../models/User");
const bcrypt = require("bcryptjs");
const CustomError = require("../../utils/errors/CustomError");

async function changePassword(params, userID) {
  const { currentPassword, newPassword } = params;
  const { id } = userID;
  const userData = await User.findById(id).select("password");
  const isMatch = bcrypt.compareSync(currentPassword, userData.password);
  if (!isMatch) throw new CustomError("Incorrect current password", 401);
  const hashPassword = bcrypt.hashSync(newPassword, 10);
  userData.password = hashPassword;
  await userData.save();
  return "Password updated successfully";
}
module.exports = changePassword;
