const User = require("../../models/User");
const jwt=require('jsonwebtoken');
const CustomError = require("../../utils/errors/CustomError");
const sendResetPasswordMail=require("../../helpers/sendEmail")

async function forgotPassword(params) {
  const { email } = params;
  const userData = await User.findOne({ email: email });
  if (!userData)
    throw new CustomError("User with this email does not exist", 401);
  // todo: generate token with JWT
  const token = jwt.sign({ _id: userData._id }, process.env.JWT_SECRET_KEY, {expiresIn: "2m"});
  userData.token=token;
  await userData.save();

  // wait for the email send
  await sendResetPasswordMail(userData.name, userData.email, token);

  return "Password reset email has been send.....please check your email";
}
module.exports = forgotPassword;
