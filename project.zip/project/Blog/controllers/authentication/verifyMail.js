const User = require("../../models/User");
const CustomError = require("../../utils/errors/CustomError");

async function verifyMail(query) {
  const updateObj = await User.updateOne(
    { _id: query.id },
    { $set: { isVerified: 1 } },
    {new: true}
  );
  if(!updateObj) throw new CustomError("Something went wrong", 500);
  return updateObj;
}

module.exports = verifyMail;