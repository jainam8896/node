const Post = require("../../models/Post");
const CustomError = require("../../utils/errors/CustomError");

async function deletePost(postId) {
  const { id } = postId;
  const post = await Post.findByIdAndDelete(id);
  if (!post) throw new CustomError("Post not found", 404);
  return "Post deleted successfully";
}

module.exports = deletePost;
