const Post = require("../../models/Post");
const CustomError = require("../../utils/errors/CustomError");

async function getPost(postId) {
  const {id}=postId;
  const posts = await Post.findById({_id: id});
  if (!posts) throw new CustomError("No post found", 404);
  return posts;
}

module.exports = getPost;
