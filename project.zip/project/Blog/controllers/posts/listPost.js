const Post = require("../../models/Post");
const CustomError = require("../../utils/errors/CustomError");

async function listPost(query) {
  var page = Number(query.page) || 1;
  const { search } = query;
  const limit = 2;
  const posts = await Post.find({
    $or: [
      { title: { $regex: ".*" + search + ".*", $options: "i" } },
      { content: { $regex: ".*" + search + ".*", $options: "i" } },
    ],
  })
  .select(["title", "content", "postimage", "category"])
  .limit(limit * 1)
  .skip((page - 1) * limit)
  .exec();
  if (!posts) throw new CustomError("No post found", 404);
  return {posts, page};
}

module.exports = listPost;
