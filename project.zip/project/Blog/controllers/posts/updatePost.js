const Post = require("../../models/Post");
const CustomError = require("../../utils/errors/CustomError");
const deleteFile = require("../../helpers/deleteFile");
const path = require("path");

async function updatePost(params, authUser, postId, image) {
  const { id } = postId;
  const { title, content, category } = params;
  const postData = await Post.findById({ _id: id });
  const filePath = postData.postimage;
  const updatePostObj = await Post.findByIdAndUpdate(
    id,
    {
      $set: {
        title: title,
        content: content,
        postimage: image.filename,
        user: authUser._id,
        category: category,
      },
    },
    { new: true }
  );
  if (!updatePostObj) throw new CustomError("Post not found", 404);
  const fullPath = "/Users/c54/Desktop/project/Blog/public/postimage";
  const filePath1 = path.join(fullPath, filePath);
  deleteFile(filePath1);
  const responseObj = await updatePostObj.save();
  return responseObj;
}

module.exports = updatePost;
