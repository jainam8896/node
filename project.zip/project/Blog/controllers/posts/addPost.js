const Post = require("../../models/Post");

async function addPost(params, authUser, image) {
  const { title, content, category } = params;
  const newPostObj = new Post({
    title: title,
    content: content,
    postimage: image.filename,
    user: authUser._id,
    category: category,
  });
  const responseObj = await newPostObj.save();
  return responseObj;
}

module.exports = addPost;
