module.exports = (err, req, res, next) => {
  err.status = err.status || 500;
  err.statusCode = err.statusCode || 'BAD_REQUEST';
  console.log(err);
  return res.status(err.status).json({
    // status: err.statusCode, 
    message: err.message,
    // statusCode: err.statusCode
  });
};
