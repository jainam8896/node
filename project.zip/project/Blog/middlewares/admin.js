const User = require("../models/user.model.js");

const checkRole = async (req, res, next) => {
    try {
        console.log(req.user.role);
        if (req.user.role === 'admin') {
            next();
        } else {
            res.status(400).send({ success: false, message: "Only admins can access it" });
        }
    }
    catch (err) {
        res.status(401).send({ success: true, message: "Unauthorized user" });
    }
}
module.exports = checkRole;