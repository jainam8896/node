const nodemailer = require("nodemailer");

module.exports = async (name, email, id) => {
  try {
    const transporter = nodemailer.createTransport({
      host: "smtp.ionos.com",
      port: 587,
      secure: false,
      requireTLS: true,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    });
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "For email verification",
      html:
        "<p>Hii " +
        name +
        ", Please click here to verify <a href='http://localhost:5000/api/v1/authentication/verify?id=" +
        id +
        "'> your email id</a> ",
    };
    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Mail has been sent:- "+info.response);
      }
    });
  } catch (error) {
    console.log(error.message);
  }
};
