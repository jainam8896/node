const mongoose = require("mongoose");
const CustomError = require("../utils/errors/CustomError");

const schema = mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
      required: [true, "Name is required"],
    },
    email: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    mobile: {
      type: Number,
      trim: true,
      minLength: [10, "no should have minimum 10 digits"],
      maxLength: [10, "no should have maximum 10 digits"],
      unique: true,
      required: true,
    },
    profileimage: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true,
      trim: true,
      select: false,
    },
    isVerified: {
      type: Number,
      default: 0
    },
    token: {
      type: String,
    },
    loginAttempts: {
      type: Number,
      default: 0
    },
    lockTime: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true,
  }
);

schema.post('save', function(error, doc, next) {
  if (error.name === 'MongoServerError' && error.code === 11000) {
    next(new CustomError('There was a duplicate key error', 400));
  } else {
    next();
  }
});

const User = mongoose.model("User", schema);
module.exports = User;
