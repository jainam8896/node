const mongoose = require('mongoose');
const schema = mongoose.Schema({
    category: {
        type: String,
        required: true,
    },
    parent: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        default: null
    }
},
    {
        timestamps: true
    }
);

schema.pre('find', function () {
    this.populate('parent');
});


const Category = mongoose.model("Category", schema);
module.exports = Category;         