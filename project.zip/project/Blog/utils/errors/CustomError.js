class CustomError extends Error {
  constructor(message, status , statusCode, data = {}) {
    super(message);
    this.status = status;
    this.statusCode = statusCode;
    this.data = data;
    Error.captureStackTrace(this, this.constructor);
  }
}
module.exports = CustomError;

// 403 statusCode = FORBIDDEN
// 403 statusCode = SESSION_EXPIRED