const { check, query, body } = require("express-validator");

const signupValidation = [
  body("name").notEmpty().withMessage("Name is required"),
  body("email").notEmpty().withMessage("Email is required"),
  body("email").isEmail().withMessage("Not a valid e-mail address"),
  body("profileimage")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("mobile")
    .isLength({ min: 10, max: 10 })
    .withMessage("Mobile number should contain 10 digit"),
  // body("fileDestination").notEmpty().withMessage("Please select the file"),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Minimum 6 characters required")
    .isLength({ max: 12 })
    .withMessage("Maximum 12 characters only allowed"),
  body("confirmpassword")
    .custom((value, { req }) => {
      return value === req.body.password;
    })
    .withMessage("Passwords do not match"),
];

const loginValidation = [
  body("email").notEmpty().withMessage("Email is required"),
  body("password").notEmpty().withMessage("Password is required"),
];

const updateUserValidation = [
  body("name").notEmpty().withMessage("Name is required"),
  body("email").notEmpty().withMessage("Email is required"),
  body("email").isEmail().withMessage("Not a valid e-mail address"),
  body("profileimage")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("mobile")
    .isLength({ min: 10, max: 10 })
    .withMessage("Mobile number should contain 10 digit"),
];

const changePasswordValidation = [
  body("currentPassword")
    .notEmpty()
    .withMessage("Please enter your current password"),
  body("newPassword")
    .isLength({ min: 6 })
    .withMessage("Minimum 6 characters required")
    .isLength({ max: 12 })
    .withMessage("Maximum 12 characters only allowed"),
  body("confirmPassword")
    .custom((value, { req }) => {
      return value === req.body.newPassword;
    })
    .withMessage("Passwords do not match"),
];

const forgotPasswordValidation = [
  body("email").notEmpty().withMessage("Email is required"),
];

const resetPasswordValidation = [
  body("newPassword")
    .isLength({ min: 6 })
    .withMessage("Minimum 6 characters required")
    .isLength({ max: 12 })
    .withMessage("Maximum 12 characters only allowed"),
  query("token").notEmpty().withMessage("Token not found"),
  body("confirmPassword")
    .custom((value, { req }) => {
      return value === req.body.newPassword;
    })
    .withMessage("Passwords do not match"),
];

const postValidation = [
  body("title").notEmpty().withMessage("Title is required"),
  body("content").notEmpty().withMessage("Content is required"),
  check("postimage")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("category").notEmpty().withMessage("Category is required"),
];

const categoryValidation = [
  body("category").notEmpty().withMessage("Category name is required"),
  body("parent").notEmpty().withMessage("Parent id is required"),
];
module.exports = {
  signupValidation,
  loginValidation,
  updateUserValidation,
  changePasswordValidation,
  forgotPasswordValidation,
  resetPasswordValidation,
  postValidation,
  categoryValidation,
};
