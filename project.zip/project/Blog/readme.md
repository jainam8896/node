# Concepts


1) Error Middleware
2) Express generattor
    https://expressjs.com/en/starter/generator.html
    https://express-validator.github.io/docs/api/express-validator
3) http-errors
    https://www.npmjs.com/package/http-errors   
4) Custom Http Error Class
5) Debug Nodejs Application 
6) Git Branching Stretegy

## Modules:




## Validations

 express-validator

 https://express-validator.github.io/docs/        