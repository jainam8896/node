const dotenv = require("dotenv");
const cors = require("cors");
dotenv.config();
const express = require("express");
require("./services/database.js");
const app = express();
const CustomError = require("./utils/errors/CustomError.js");
const errorHandler = require("./middlewares/errorHandler.js");

app.use(cors());
app.use(express.json());
app.use("/api/v1", require("./routes/index.routes.js"));


app.all("*", (req, res, next) => {
  const error = new CustomError(
    `Can't find ${req.originalUrl} on the server`,
    404
  );
  next(error);
});
app.use(errorHandler);

app.listen(process.env.PORT, () => {
  console.log(`Server is running at port.....`);
  // const crypto = require('crypto');
  // console.log(crypto.randomUUID());
});
