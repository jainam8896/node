const User = require("../../models/User");
const bcrypt = require("bcrypt");
const { validationResult } = require("express-validator");

//User signup
const userRegistration = async (req, res) => {
  const { name, email, age, password, address } = req.body;
  try {
    const user = await User.findOne({ email: email });
    if (user) {
      return res
        .status(401)
        .json({ status: "failed", message: "Email Already Exists" });
    }
    const salt = bcrypt.genSaltSync(10);
    const hasPassword = bcrypt.hashSync(password, salt);
    const doc = new User({
      name: name,
      email: email,
      age: age,
      password: hasPassword,
      address: address,
    });
    await doc.save();
    res.send({ status: "success", message: "User Registration Success" });
  } catch (error) {
    res.send({ status: "failed", message: "Unable to Register" });
  }
};

module.exports = userRegistration;
