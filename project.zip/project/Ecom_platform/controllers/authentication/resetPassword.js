const User = require("../../models/User");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

const resetPassword = async (req, res, query) => {
  const token = query.token;
  const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
  const { newPassword } = req.body;
  const userData = await User.findById({ _id });
  if (!userData) {
    return res.status(400).json("This Link Is not valid");
  }
  const hashPassword = bcrypt.hashSync(newPassword, 10);
  userData.password = hashPassword;
  userData.token = null;
  await userData.save();
  return "Your Password Updated Successfully";
};

module.exports = resetPassword;
