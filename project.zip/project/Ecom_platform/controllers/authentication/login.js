require("dotenv").config({});
const User = require("../../models/User");
const bcrypt = require("bcrypt");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");

//User login
const userLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    // const user = await User.findOne({ email: email }).select(["password"]);
    const user = await User.findOne({ email: email });
    if (!user) {
      return res
        .status(401)
        .send({ status: "failed", message: "User Not Register" });
    }
    const Match = bcrypt.compareSync(password, user.password);
    if (!Match) {
      return res
        .status(401)
        .send({ status: "failed", message: "Email Or Password doesn't match" });
    }
    const token = jwt.sign({ _id: user._id }, process.env.JWT_SECRET_KEY, {
      expiresIn: "5d",
    });
    return res
      .status(200)
      .json({ status: "failed", message: "User Login Success", token: token });
  } catch (error) {
    res.status(401).send({ status: "failed", message: "Unable to login" });
  }
};

module.exports = userLogin;
