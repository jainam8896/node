const Category = require("../../models/Category");

//Display category
const listCategory = async (req,res) =>{
    try {
        const category = await Category.find({})
        if(!category){
            return res.json('Category not found!')
        }
        res.json(category)
    } catch (error) {
        res.json(error)
    }
}

module.exports = listCategory