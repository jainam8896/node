const Category = require("../../models/Category");

//Delete Category
const deletcategory = async (req,res) => {
    try {
        const { id } = req.params
        const category = await Category.findByIdAndDelete(id)
        if (!category) {
            res.send({ status: "failed", message: "Category Not Found" });
        }
        res.send({ status: "success", message: "Category Deleted Successfully" });
    } catch (error) {
        res.json(error.message);
    }
}

module.exports = deletcategory