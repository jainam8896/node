const User = require("../../models/User");

const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findByIdAndDelete(id);
    if (!user) {
      return res.status(404).json("User is not found!");
    }
    return res.status(200).json("User Deleted Successfully");
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = deleteUser;
