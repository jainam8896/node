const express = require("express");
const router = express.Router();
const createProduct = require('../controllers/products/create')

//Create Product
router.post('/create',createProduct)

module.exports = router;