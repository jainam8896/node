const express = require("express");
const router = express.Router();
const userRoute = require("./users.routes.js");
const categoryRoute = require("./category.routes.js");
const productRoute = require("./product.routes.js")

// /authentication/
router.use("/users", userRoute);
router.use("/categories", categoryRoute);
router.use("/products",productRoute)

module.exports = router;
