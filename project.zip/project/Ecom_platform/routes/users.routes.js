const express = require("express");
const router = express.Router();
const rules = require("../utils/validations/user/validation");
const userRegistration = require("../controllers/authentication/signup");
const userLogin = require("../controllers/authentication/login");
const validate = require("../middlewares/validate");
const auth = require("../middlewares/auth");
const changePassword = require("../controllers/authentication/changepassword");
const deleteUser = require("../controllers/users/delete");
const getUser = require("../controllers/users/get");
const updateUser = require("../controllers/users/update");
const forgetPassword = require("../controllers/authentication/forgetPassword");
const resetPassword = require("../controllers/authentication/resetPassword");

router.post("/signup", validate(rules.registerValidator), userRegistration);

router.post("/login", validate(rules.loginValidator), userLogin);

router.post(
  "/changePassword",
  validate(rules.changePasswordValidator),
  auth,
  changePassword
);

router.post(
  "/forgetpassword",
  validate(rules.forgetPasswordValidator),
  forgetPassword
);

router.post(
  "/resetpassword",
  validate(rules.resetPasswordValidator),
  resetPassword
);

router.delete("/:id", auth, deleteUser);

router.get("/:id", auth, getUser);

router.put("/:id", auth, updateUser);

module.exports = router;
