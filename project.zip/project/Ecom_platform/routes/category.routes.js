const express = require("express");
const router = express.Router();
const categoryValidation = require("../utils/validations/category/validation.js");
const createCategory = require("../controllers/categories/create");
const deletcategory = require("../controllers/categories/delete.js");
const listCategory = require("../controllers/categories/list.js");
const getCategory = require("../controllers/categories/get.js");
const updateCategory = require("../controllers/categories/update.js");

//Create Category
router.post("/create", categoryValidation, createCategory);

//Delete Category
router.delete("/:id", deletcategory);

//Display Category
router.get("/", listCategory);

//Get Category
router.get("/:id", getCategory);

//Update Category
router.put("/:id", updateCategory);

module.exports = router;
