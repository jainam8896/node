const { body } = require("express-validator");

const categoryValidation = [
  body("name").notEmpty().withMessage("Category name is required"),
];

module.exports = categoryValidation
