const { body } = require("express-validator");

const productValidator = [
  body("productName").notEmpty().withMessage("Product is required"),
  body("productDescription").notEmpty().withMessage("Product Description is required"),
  body("productPrice").isEmail().withMessage("Not a valid e-mail address"),
  body("age").notEmpty().withMessage("Age is required"),
  body("age").isInt({ min: 18, max: 120 }).withMessage("Please Enter Valid Age"),
  body("address").notEmpty().withMessage("Address Is required"),
  body("password")
    .isStrongPassword({
      minLength: 6,
      minUppercase: 1,
      minLowercase: 1,
      minNumber: 1,
    })
    .withMessage(
      "Password must be grater than 6 character, and contain atleast one uppercase, atleast one lower case letter, and one number, and one special character"
    ),
];