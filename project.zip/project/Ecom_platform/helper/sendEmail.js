const nodemailer = require("nodemailer");

module.exports = async (name, email, token) => {
  try {
    const transporter = nodemailer.createTransport({
      host: "smtp.ionos.com",
      port: 587,
      secure: false,
      requireTLS: true,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    });
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "For reset password",
      html:
        "<p>Hii " +
        name +
        ", Please copy the link and<a href='http://localhost:8080/api/v1/user/resetpassword?token=" +
        token +
        "'> reset your password</a> ",
    };
    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        console.log(error);
      } else {
        console.log("Mail has been sent");
      }
    });
  } catch (error) {
    console.log(error.message);
  }
};
